// 📄 完整替换文件：Widgets/WidgetBubble.swift
import SwiftUI
import PhotosUI

final class BubbleWidgetPlugin: BaseWidgetPlugin {
    override class func register() {
        WidgetRegistry.shared.registerBubbleWidget()
    }
}

class ChatBubbleWidgetManager: ObservableObject {
    static let shared = ChatBubbleWidgetManager()
    
    // MARK: - 持久化存储键 (Strict & Complete)
    private let photoIdKey = "App_Widget_2x2_Bubble_ImageID"
    private let firstKey = "App_Widget_2x2_Bubble_FirstText"
    private let secondKey = "App_Widget_2x2_Bubble_SecondText"
    private let addedKey = "App_Widget_2x2_Bubble_IsAdded"
    private let pageKey = "App_Widget_2x2_Bubble_PagePosition"
    private let rowKey = "App_Widget_2x2_Bubble_RowPosition"
    private let colKey = "App_Widget_2x2_Bubble_ColPosition"
    private let transparentKey = "App_Widget_2x2_Bubble_IsTransparent"
    
    // 底板颜色与模式
    private let bgColorModeKey = "App_Widget_2x2_Bubble_BgColorMode"
    private let widgetBgColorKey = "App_Widget_2x2_Bubble_WidgetBgColorHex"
    
    // 气泡药丸、文字、日期与字重
    private let bubbleColorKey = "App_Widget_2x2_Bubble_BgColor"
    private let textColorKey = "App_Widget_2x2_Bubble_TextColor"
    private let dateColorKey = "App_Widget_2x2_Bubble_DateColor"
    private let bubbleWeightKey = "App_Widget_2x2_Bubble_TextWeight"
    
    // 🌟 对齐相册插画：配图描边与圆角
    private let hasImgBorderKey = "App_Widget_2x2_Bubble_HasImgBorder"
    private let imgBorderWidthKey = "App_Widget_2x2_Bubble_ImgBorderWidth"
    private let imgBorderColorKey = "App_Widget_2x2_Bubble_ImgBorderColor"
    private let imgRadiusKey = "App_Widget_2x2_Bubble_ImgRadius"
    
    // 🌟 对齐相册插画：配图旁边的分享/转发小图标
    private let showShareIconKey = "App_Widget_2x2_Bubble_ShowShareIcon"
    private let shareIconBgKey = "App_Widget_2x2_Bubble_ShareIconBgHex"
    private let shareIconColorKey = "App_Widget_2x2_Bubble_ShareIconColorHex"
    
    // MARK: - 发布属性
    @Published var widgetImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: photoIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: widgetImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.photoIdKey)
            }
        }
    }
    
    @Published var firstBubbleText: String {
        didSet {
            UserDefaults.standard.set(firstBubbleText, forKey: firstKey)
            AutoTranslationManager.shared.prewarm(text: firstBubbleText)
        }
    }
    
    @Published var secondBubbleText: String {
        didSet {
            UserDefaults.standard.set(secondBubbleText, forKey: secondKey)
            AutoTranslationManager.shared.prewarm(text: secondBubbleText)
        }
    }
    
    @Published var bgColorMode: String {
        didSet {
            UserDefaults.standard.set(bgColorMode, forKey: bgColorModeKey)
            isTransparentBackground = (bgColorMode == "transparent")
        }
    }
    
    @Published var widgetBgColorHex: String {
        didSet { UserDefaults.standard.set(widgetBgColorHex, forKey: widgetBgColorKey) }
    }
    
    @Published var isTransparentBackground: Bool {
        didSet { UserDefaults.standard.set(isTransparentBackground, forKey: transparentKey) }
    }
    
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    @Published var widgetCol: Int { didSet { UserDefaults.standard.set(widgetCol, forKey: colKey) } }
    
    @Published var bubbleColorHex: String { didSet { UserDefaults.standard.set(bubbleColorHex, forKey: bubbleColorKey) } }
    @Published var textColorHex: String { didSet { UserDefaults.standard.set(textColorHex, forKey: textColorKey) } }
    @Published var dateColorHex: String { didSet { UserDefaults.standard.set(dateColorHex, forKey: dateColorKey) } }
    @Published var bubbleTextWeightName: String { didSet { UserDefaults.standard.set(bubbleTextWeightName, forKey: bubbleWeightKey) } }
    
    // 配图描边与圆角
    @Published var hasImageBorder: Bool { didSet { UserDefaults.standard.set(hasImageBorder, forKey: hasImgBorderKey) } }
    @Published var imageBorderWidth: Double { didSet { UserDefaults.standard.set(imageBorderWidth, forKey: imgBorderWidthKey) } }
    @Published var imageBorderColorHex: String { didSet { UserDefaults.standard.set(imageBorderColorHex, forKey: imgBorderColorKey) } }
    @Published var imageCornerRadius: Double { didSet { UserDefaults.standard.set(imageCornerRadius, forKey: imgRadiusKey) } }
    
    // 分享图标
    @Published var showShareIcon: Bool { didSet { UserDefaults.standard.set(showShareIcon, forKey: showShareIconKey) } }
    @Published var shareIconBgHex: String { didSet { UserDefaults.standard.set(shareIconBgHex, forKey: shareIconBgKey) } }
    @Published var shareIconColorHex: String { didSet { UserDefaults.standard.set(shareIconColorHex, forKey: shareIconColorKey) } }
    
    // MARK: - 计算色彩与属性
    var widgetBgColor: Color { Color(hex: widgetBgColorHex) }
    var bubbleColor: Color { Color(hex: bubbleColorHex) }
    var bubbleTextColor: Color { Color(hex: textColorHex) }
    var dateTextColor: Color { Color(hex: dateColorHex) }
    var bubbleTextWeight: Font.Weight { Font.Weight.from(name: bubbleTextWeightName) }
    var imageBorderColor: Color { Color(hex: imageBorderColorHex) }
    var shareIconBg: Color { Color(hex: shareIconBgHex) }
    var shareIconColor: Color { Color(hex: shareIconColorHex) }
    
    init() {
        let ud = UserDefaults.standard
        if let savedId = ud.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        self.firstBubbleText = ud.string(forKey: firstKey) ?? "幼"
        self.secondBubbleText = ud.string(forKey: secondKey) ?? "其实很可爱的哦..."
        
        let savedTransparent = ud.bool(forKey: transparentKey)
        self.isTransparentBackground = savedTransparent
        self.bgColorMode = ud.string(forKey: bgColorModeKey) ?? (savedTransparent ? "transparent" : "color")
        self.widgetBgColorHex = ud.string(forKey: widgetBgColorKey) ?? "#F2F2F7"
        
        self.isAddedToDesktop = ud.bool(forKey: addedKey)
        self.widgetPage = ud.integer(forKey: pageKey)
        let rawRow = ud.object(forKey: rowKey) != nil ? ud.integer(forKey: rowKey) : 2
        self.widgetRow = min(max(0, rawRow), 4)
        let rawCol = ud.integer(forKey: colKey)
        self.widgetCol = (rawCol > 0) ? 2 : 0
        
        self.bubbleColorHex = ud.string(forKey: bubbleColorKey) ?? "#E5E5EA"
        self.textColorHex = ud.string(forKey: textColorKey) ?? "#000000"
        self.dateColorHex = ud.string(forKey: dateColorKey) ?? "#8E8E93"
        self.bubbleTextWeightName = ud.string(forKey: bubbleWeightKey) ?? "medium"
        
        // 配图描边与圆角默认值（经典还原，默认开启细腻描边与 12pt 圆角）
        self.hasImageBorder = ud.object(forKey: hasImgBorderKey) != nil ? ud.bool(forKey: hasImgBorderKey) : true
        self.imageBorderWidth = ud.object(forKey: imgBorderWidthKey) != nil ? ud.double(forKey: imgBorderWidthKey) : 0.8
        self.imageBorderColorHex = ud.string(forKey: imgBorderColorKey) ?? "#D1D1D6"
        self.imageCornerRadius = ud.object(forKey: imgRadiusKey) != nil ? ud.double(forKey: imgRadiusKey) : 12.0
        
        // 分享图标默认值（经典还原，默认开启、灰色质感底、白色箭头）
        self.showShareIcon = ud.object(forKey: showShareIconKey) != nil ? ud.bool(forKey: showShareIconKey) : true
        self.shareIconBgHex = ud.string(forKey: shareIconBgKey) ?? "#8E8E93"
        self.shareIconColorHex = ud.string(forKey: shareIconColorKey) ?? "#FFFFFF"
        
        AutoTranslationManager.shared.prewarm(text: firstBubbleText)
        AutoTranslationManager.shared.prewarm(text: secondBubbleText)
    }
}

// MARK: - 2x2 对话框实体视图
struct ChatBubbleWidget2x2View: View {
    @ObservedObject var manager: ChatBubbleWidgetManager = .shared
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    
    var imageData: Data? = nil
    var firstBubbleText: String = "幼"
    var secondBubbleText: String = "其实很可爱的哦..."
    var isTransparent: Bool = false
    var widgetBgColor: Color? = nil
    var bubbleColor: Color = Color(UIColor.systemGray5)
    var bubbleTextColor: Color = .primary
    var dateTextColor: Color = Color.secondary.opacity(0.75)
    var bubbleTextWeight: Font.Weight = .medium
    var showDashedBorder: Bool = false
    
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    @State private var currentDate: Date = Date()
    private static let sharedFormatter = DateFormatter()
    
    private var formattedDate: String {
        Self.sharedFormatter.locale = Locale(identifier: lang.currentLanguage.localeIdentifier)
        switch lang.currentLanguage {
        case .simplifiedChinese, .traditionalChinese: Self.sharedFormatter.dateFormat = "M月d日 EEEE"
        case .english: Self.sharedFormatter.dateFormat = "EEEE, MMM d"
        case .japanese: Self.sharedFormatter.dateFormat = "M月d日(EEEE)"
        case .korean: Self.sharedFormatter.dateFormat = "M월 d일 EEEE"
        }
        return Self.sharedFormatter.string(from: currentDate)
    }
    
    private func effectiveWeight(_ customWeight: Font.Weight) -> Font.Weight {
        appearance.preferWidgetFontPriority ? customWeight : appearance.systemFontWeight
    }
    
    private var actualBackgroundColor: Color {
        if isTransparent || manager.isTransparentBackground || manager.bgColorMode == "transparent" {
            return Color.clear
        }
        return widgetBgColor ?? manager.widgetBgColor
    }
    
    var body: some View {
        let s = uiScale
        
        ZStack(alignment: .topLeading) {
            VStack(alignment: .leading, spacing: 5 * s) {
                // 顶部日期
                HStack {
                    Spacer()
                    Text(formattedDate)
                        .font(.system(size: 8.5 * s))
                        .fontWeight(appearance.systemFontWeight)
                        .foregroundColor(dateTextColor)
                        .lineLimit(1)
                    Spacer()
                }
                .padding(.top, -3 * s)
                
                // 第一条气泡
                HStack {
                    Text(translator.translate(firstBubbleText))
                        .font(.system(size: 10 * s))
                        .fontWeight(effectiveWeight(bubbleTextWeight))
                        .foregroundColor(bubbleTextColor)
                        .lineLimit(1)
                        .padding(.horizontal, 8 * s)
                        .padding(.vertical, 3 * s)
                        .background(bubbleColor)
                        .clipShape(Capsule())
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10 * s)
                
                // 中间行：配图 + 分享小图标
                HStack(alignment: .bottom, spacing: 6 * s) {
                    let r = CGFloat(manager.imageCornerRadius) * s
                    
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                        Group {
                            let currentImage = manager.widgetImageData ?? imageData
                            if let data = currentImage, let uiImage = ImageBitmapCache.shared.image(from: data) {
                                Image(uiImage: uiImage).resizable().scaledToFill()
                            } else {
                                ZStack {
                                    Color(UIColor.systemGray6)
                                    Image(systemName: "photo")
                                        .font(.system(size: 24 * s))
                                        .foregroundColor(.secondary.opacity(0.5))
                                }
                            }
                        }
                        .frame(width: 114 * s, height: 64 * s)
                        .clipShape(RoundedRectangle(cornerRadius: r, style: .continuous))
                        .overlay(
                            Group {
                                if manager.hasImageBorder {
                                    RoundedRectangle(cornerRadius: r, style: .continuous)
                                        .stroke(manager.imageBorderColor, lineWidth: CGFloat(manager.imageBorderWidth) * s)
                                }
                            }
                        )
                    }
                    .buttonStyle(.plain)
                    
                    // 🌟 经典分享/转发图标小圆钮（完整变量驱动，绝不丢失）
                    if manager.showShareIcon {
                        ZStack {
                            Circle()
                                .fill(manager.shareIconBg)
                                .frame(width: 18 * s, height: 18 * s)
                            
                            Image(systemName: "arrowshape.turn.up.right.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 8.5 * s, height: 8.5 * s)
                                .foregroundColor(manager.shareIconColor)
                                .offset(x: 0, y: -0.4 * s)
                        }
                        .padding(.bottom, 2 * s)
                    }
                    
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10 * s)
                
                // 第二条气泡
                HStack {
                    Text(translator.translate(secondBubbleText))
                        .font(.system(size: 9.5 * s))
                        .fontWeight(effectiveWeight(bubbleTextWeight))
                        .foregroundColor(bubbleTextColor)
                        .lineLimit(1)
                        .padding(.horizontal, 8 * s)
                        .padding(.vertical, 3.5 * s)
                        .background(bubbleColor)
                        .clipShape(Capsule())
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10 * s)
                .padding(.bottom, 6 * s)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(actualBackgroundColor)
            .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                    .stroke(
                        (isTransparent || manager.bgColorMode == "transparent") ? (showDashedBorder ? Color.secondary.opacity(0.4) : Color.clear) : Color.white.opacity(0.2),
                        style: StrokeStyle(lineWidth: 1 * s, dash: ((isTransparent || manager.bgColorMode == "transparent") && showDashedBorder) ? [5 * s, 4 * s] : [])
                    )
            )
            .contentShape(Rectangle())
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.significantTimeChangeNotification).receive(on: DispatchQueue.main)) { _ in
            currentDate = Date()
        }
        .task(id: selectedPhotoItem) {
            if let data = try? await selectedPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.25)) {
                    manager.widgetImageData = data
                }
                UINotificationFeedbackGenerator().notificationOccurred(.success)
            }
        }
    }
}

extension WidgetRegistry {
    func registerBubbleWidget() {
        let mgr = ChatBubbleWidgetManager.shared
        let s = uiScale
        registerWidget(
            id: "bubble",
            title: "widget_bubble_title",
            subtitle: "sub_bubble",
            badge: "2×2",
            manager: mgr,
            desktopView: {
                ChatBubbleWidget2x2View(
                    manager: mgr,
                    imageData: mgr.widgetImageData,
                    firstBubbleText: mgr.firstBubbleText,
                    secondBubbleText: mgr.secondBubbleText,
                    isTransparent: mgr.isTransparentBackground,
                    widgetBgColor: mgr.widgetBgColor,
                    bubbleColor: mgr.bubbleColor,
                    bubbleTextColor: mgr.bubbleTextColor,
                    dateTextColor: mgr.dateTextColor,
                    bubbleTextWeight: mgr.bubbleTextWeight
                )
            },
            previewView: {
                ChatBubbleWidget2x2View(
                    manager: mgr,
                    imageData: mgr.widgetImageData,
                    firstBubbleText: mgr.firstBubbleText,
                    secondBubbleText: mgr.secondBubbleText,
                    isTransparent: mgr.isTransparentBackground,
                    widgetBgColor: mgr.widgetBgColor,
                    bubbleColor: mgr.bubbleColor,
                    bubbleTextColor: mgr.bubbleTextColor,
                    dateTextColor: mgr.dateTextColor,
                    bubbleTextWeight: mgr.bubbleTextWeight
                ).frame(width: 160 * s, height: 160 * s)
            },
            editSheetView: { show in
                EditBubbleWidgetSheet(isPresented: show)
            }
        )
    }
}
