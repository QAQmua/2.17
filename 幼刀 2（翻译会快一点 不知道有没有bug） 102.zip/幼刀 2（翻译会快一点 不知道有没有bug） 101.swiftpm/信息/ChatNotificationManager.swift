// 📄 完整替换文件：信息/ChatNotificationManager.swift
import SwiftUI
import UserNotifications
import Intents
import AVFoundation
import UIKit

@MainActor
class ChatNotificationManager: NSObject, UNUserNotificationCenterDelegate {
    static let shared = ChatNotificationManager()
    
    // 🌟 后台保活组件（防止切到其他软件或锁屏时 WebSocket 被 iOS 冻结断连）
    private var bgTask: UIBackgroundTaskIdentifier = .invalid
    private var silentPlayer: AVAudioPlayer?
    private var keepAliveTimer: Timer?
    
    // 记录当前用户正在看的会话 ID（如果在前台且正好在看这个人的聊天窗，就不重复弹横幅吵人；若在后台或锁屏则 100% 弹窗）
    public var activeViewingConversationID: String? = nil
    
    private override init() {
        super.init()
        UNUserNotificationCenter.current().delegate = self
        setupBackgroundLifecycleHooks()
        prepareSilentAudioKeepAlive()
    }
    
    /// 1. 请求系统锁屏、横幅、声音与通信通知权限
    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge, .providesAppNotificationSettings]) { granted, error in
            if let error = error {
                print("❌ 通知授权失败: \(error.localizedDescription)")
            }
        }
    }
    
    /// 2. 触发带「自定义联系人头像」的系统锁屏与横幅通知（支持连发多条逐条弹出）
    func scheduleMessageNotification(
        messageID: String = UUID().uuidString,
        senderName: String,
        messageText: String,
        conversationID: String,
        avatarImageID: String? = nil,
        avatarColorHex: String = "#007AFF",
        hasImageAttachment: Bool = false
    ) {
        // 如果当前 App 在前台，且用户正好停留在该联系人的聊天窗口内，则无需弹顶部横幅（已有气泡音效）
        let appState = UIApplication.shared.applicationState
        if appState == .active && activeViewingConversationID == conversationID {
            return
        }
        
        let baseContent = UNMutableNotificationContent()
        baseContent.title = senderName
        baseContent.body = messageText.isEmpty ? (hasImageAttachment ? "[图片]" : "发来一条新信息") : messageText
        baseContent.sound = .default
        baseContent.threadIdentifier = conversationID
        baseContent.categoryIdentifier = "IMESSAGE_DIRECT_CATEGORY"
        
        // 🌟 准备联系人的真实头像数据（如果没设照片，自动渲染一张高清圆形渐变首字母头像）
        let avatarData: Data? = {
            if let id = avatarImageID,
               let raw = LocalImageStore.shared.load(id: id),
               let uiImg = UIImage(data: raw),
               let circularData = Self.renderCircularAvatarPNG(image: uiImg, size: 160) {
                return circularData
            }
            return Self.renderMonogramAvatarPNG(name: senderName, colorHex: avatarColorHex, size: 160)
        }()
        
        // 🌟 核心 1：写入临时沙盒作为通知右侧高清缩略图附件（100% 兼容所有 iOS 版本显示头像）
        if let data = avatarData {
            let tmpURL = FileManager.default.temporaryDirectory.appendingPathComponent("avatar_\(messageID).png")
            if (try? data.write(to: tmpURL)) != nil,
               let attachment = try? UNNotificationAttachment(identifier: "avatar_\(messageID)", url: tmpURL, options: nil) {
                baseContent.attachments = [attachment]
            }
        }
        
        // 🌟 核心 2：构建 Apple 原生 INSendMessageIntent 通信通知（让系统横幅左侧直接展示联系人头像）
        var finalContent: UNNotificationContent = baseContent
        if let data = avatarData {
            let inImage = INImage(imageData: data)
            let handle = INPersonHandle(value: conversationID, type: .unknown)
            let senderPerson = INPerson(
                personHandle: handle,
                nameComponents: nil,
                displayName: senderName,
                image: inImage,
                contactIdentifier: nil,
                customIdentifier: conversationID
            )
            
            let sendIntent = INSendMessageIntent(
                recipients: nil,
                outgoingMessageType: .outgoingMessageText,
                content: baseContent.body,
                speakableGroupName: nil,
                conversationIdentifier: conversationID,
                serviceName: "iMessage",
                sender: senderPerson,
                attachments: nil
            )
            sendIntent.setImage(inImage, forParameterNamed: \.sender)
            
            let interaction = INInteraction(intent: sendIntent, response: nil)
            interaction.direction = .incoming
            interaction.donate(completion: nil)
            
            if let updated = try? baseContent.updating(from: sendIntent) {
                finalContent = updated
            }
        }
        
        // 🌟 核心 3：0.1 秒极速触发 + 独立 messageID，连发 10 条弹出 10 条，绝不互相覆盖吞消息！
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 0.1, repeats: false)
        let request = UNNotificationRequest(
            identifier: "im_msg_\(messageID)",
            content: finalContent,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ 锁屏/后台通知派发失败: \(error.localizedDescription)")
            }
        }
    }
    
    // MARK: - 前台活跃时依然允许弹出横幅、声音与通知中心列表
    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound, .list, .badge])
    }
    
    // MARK: - 切后台与锁屏不断连保活引擎
    private func setupBackgroundLifecycleHooks() {
        NotificationCenter.default.addObserver(
            forName: UIApplication.didEnterBackgroundNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.beginBackgroundKeepAlive()
            }
        }
        
        NotificationCenter.default.addObserver(
            forName: UIApplication.willEnterForegroundNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.endBackgroundKeepAlive()
                // 回到前台立即自检重连并拉取未读队列
                MessagesNetworkEngine.shared.ensureAliveAndSync()
            }
        }
    }
    
    private func beginBackgroundKeepAlive() {
        // 1. 申请系统 Background Task 延续进程执行权
        if bgTask != .invalid {
            UIApplication.shared.endBackgroundTask(bgTask)
            bgTask = .invalid
        }
        bgTask = UIApplication.shared.beginBackgroundTask(withName: "IMessageSocketKeepAlive") { [weak self] in
            Task { @MainActor in
                if let task = self?.bgTask, task != .invalid {
                    UIApplication.shared.endBackgroundTask(task)
                    self?.bgTask = .invalid
                }
            }
        }
        
        // 2. 启动微弱静默音频流维持 Socket 线程不被系统休眠挂起
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            silentPlayer?.play()
        } catch {}
        
        // 3. 后台心跳巡检，确保网络闪断时自动重连收信
        keepAliveTimer?.invalidate()
        keepAliveTimer = Timer.scheduledTimer(withTimeInterval: 8.0, repeats: true) { _ in
            Task { @MainActor in
                MessagesNetworkEngine.shared.ensureAliveAndSync()
            }
        }
    }
    
    private func endBackgroundKeepAlive() {
        keepAliveTimer?.invalidate()
        keepAliveTimer = nil
        silentPlayer?.pause()
        if bgTask != .invalid {
            UIApplication.shared.endBackgroundTask(bgTask)
            bgTask = .invalid
        }
    }
    
    /// 内存动态合成一段极小的全静音 WAV，用于后台保活 WebSocket 接收消息
    private func prepareSilentAudioKeepAlive() {
        let sampleRate: Int32 = 8000
        let numSamples: Int32 = 8000
        let dataSize = numSamples * 2
        let fileSize = 36 + dataSize
        
        var wav = Data()
        wav.append("RIFF".data(using: .ascii)!)
        wav.append(withUnsafeBytes(of: fileSize.littleEndian) { Data($0) })
        wav.append("WAVEfmt ".data(using: .ascii)!)
        wav.append(withUnsafeBytes(of: Int32(16).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: Int16(1).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: Int16(1).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: sampleRate.littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: (sampleRate * 2).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: Int16(2).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: Int16(16).littleEndian) { Data($0) })
        wav.append("data".data(using: .ascii)!)
        wav.append(withUnsafeBytes(of: dataSize.littleEndian) { Data($0) })
        wav.append(Data(count: Int(dataSize)))
        
        if let player = try? AVAudioPlayer(data: wav) {
            player.numberOfLoops = -1
            player.volume = 0.0
            player.prepareToPlay()
            self.silentPlayer = player
        }
    }
    
    // MARK: - 圆形联系人头像绘制工具
    private static func renderCircularAvatarPNG(image: UIImage, size: CGFloat) -> Data? {
        let rect = CGRect(origin: .zero, size: CGSize(width: size, height: size))
        let renderer = UIGraphicsImageRenderer(size: rect.size)
        let img = renderer.image { ctx in
            UIBezierPath(ovalIn: rect).addClip()
            let imgSize = image.size
            let scale = max(size / max(imgSize.width, 1), size / max(imgSize.height, 1))
            let drawW = imgSize.width * scale
            let drawH = imgSize.height * scale
            let drawRect = CGRect(x: (size - drawW) / 2.0, y: (size - drawH) / 2.0, width: drawW, height: drawH)
            image.draw(in: drawRect)
        }
        return img.pngData()
    }
    
    private static func renderMonogramAvatarPNG(name: String, colorHex: String, size: CGFloat) -> Data? {
        let rect = CGRect(origin: .zero, size: CGSize(width: size, height: size))
        let renderer = UIGraphicsImageRenderer(size: rect.size)
        let baseColor = UIColor(Color(hex: colorHex))
        let img = renderer.image { ctx in
            let path = UIBezierPath(ovalIn: rect)
            path.addClip()
            baseColor.setFill()
            path.fill()
            
            let firstChar = String(name.isEmpty ? "信" : name.prefix(1))
            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center
            let font = UIFont.systemFont(ofSize: size * 0.46, weight: .bold)
            let attrs: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: UIColor.white,
                .paragraphStyle: paragraph
            ]
            let textSize = firstChar.size(withAttributes: attrs)
            let textRect = CGRect(
                x: 0,
                y: (size - textSize.height) / 2.0,
                width: size,
                height: textSize.height
            )
            firstChar.draw(in: textRect, withAttributes: attrs)
        }
        return img.pngData()
    }
}
