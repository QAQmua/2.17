// 📄 替换文件：AppCore (核心系统与桌面)/ContentView.swift
import SwiftUI

// MARK: - 全局根入口
struct ContentView: View {
    @State private var isUnlocked = false
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        ZStack {
            // 🌟 修复：系统原生自适应底色，深色模式自动为纯黑，浅色自动为纯白，绝无作用域报错
            Color(UIColor.systemBackground)
                .ignoresSafeArea()
            
            if isUnlocked {
                HomeScreenView(isUnlocked: $isUnlocked)
                    .transition(.opacity)
            } else {
                LockScreenView(isUnlocked: $isUnlocked)
                    .transition(.opacity)
            }
        }
        .preferredColorScheme(appearance.colorScheme)
    }
}
