import SwiftUI

// 📄 桌面点击左上角“+”弹出的添加小组件半屏弹窗
struct AddWidgetSheetView: View {
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: HomeScreenViewModel 
    @Binding var currentPage: Int
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var registry = WidgetRegistry.shared 
    
    @State private var selectedCategory: String = "全部"
    private let sizeCategories = ["全部", "4×4", "4×2", "2×2"]
    @State private var selectedIndex: Int = 0
    
    private var filteredWidgets: [WidgetDefinition] {
        if selectedCategory == "全部" { return registry.registeredWidgets }
        return registry.registeredWidgets.filter { isWidgetMatchingCategory(widget: $0, category: selectedCategory) }
    }
    
    private func isWidgetMatchingCategory(widget: WidgetDefinition, category: String) -> Bool {
        if category == "全部" { return true }
        
        let normalize: (String) -> String = { str in
            str.lowercased()
                .replacingOccurrences(of: "badge_", with: "")
                .replacingOccurrences(of: "×", with: "x")
                .replacingOccurrences(of: "*", with: "x")
                .trimmingCharacters(in: .whitespaces)
        }
        
        let target = normalize(category)
        let badge = normalize(widget.sizeBadgeKey)
        let translatedBadge = normalize(lang.tr(widget.sizeBadgeKey))
        
        if badge == target || translatedBadge == target || badge.contains(target) { return true }
        
        switch target {
        case "2x2": return widget.sizeCols == 2 && widget.sizeRows == 2
        case "4x2": return (widget.sizeCols == 4 && widget.sizeRows == 2) || (widget.sizeCols == 2 && widget.sizeRows == 4)
        case "4x4": return widget.sizeCols == 4 && widget.sizeRows == 4
        default: return false
        }
    }
    
    private var activeWidget: WidgetDefinition? {
        guard selectedIndex >= 0 && selectedIndex < filteredWidgets.count else { return nil }
        return filteredWidgets[selectedIndex]
    }
    
    private var isCurrentAdded: Bool {
        activeWidget?.manager.isAddedToDesktop ?? false
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 🌟 分类标签胶囊：使用全局分类标签颜色
                HStack(spacing: 8.0 * uiScale) {
                    ForEach(sizeCategories, id: \.self) { cat in
                        Button(action: {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            withAnimation(.easeInOut(duration: 0.2)) {
                                selectedCategory = cat
                                selectedIndex = 0
                            }
                        }) {
                            Text(cat == "全部" ? lang.tr("cat_all") : cat)
                                .font(.system(size: 13.0 * uiScale, weight: selectedCategory == cat ? .semibold : appearance.systemFontWeight))
                                .padding(.horizontal, 14.0 * uiScale).padding(.vertical, 6.0 * uiScale)
                                .background(selectedCategory == cat ? appearance.categoryTagColor : Color(UIColor.secondarySystemFill))
                                .foregroundColor(selectedCategory == cat ? .white : .primary)
                                .clipShape(Capsule())
                        }
                    }
                    Spacer()
                }
                .padding(.horizontal, 20.0 * uiScale).padding(.top, 12.0 * uiScale).padding(.bottom, 8.0 * uiScale)
                
                TabView(selection: $selectedIndex) {
                    ForEach(Array(filteredWidgets.enumerated()), id: \.element.id) { index, item in
                        VStack(spacing: 0) {
                            Spacer(minLength: 8.0 * uiScale)
                            item.previewView()
                            Spacer(minLength: 12.0 * uiScale)
                            VStack(spacing: 5.0 * uiScale) {
                                HStack(spacing: 6.0 * uiScale) {
                                    Text(lang.tr(item.titleKey)).font(.system(size: 19.0 * uiScale, weight: appearance.systemFontWeight)).foregroundColor(.primary)
                                    Text(lang.tr(item.sizeBadgeKey)).font(.system(size: 11.0 * uiScale, weight: appearance.systemFontWeight))
                                        .padding(.horizontal, 6.0 * uiScale).padding(.vertical, 2.0 * uiScale).background(appearance.categoryTagColor.opacity(0.15)).foregroundColor(appearance.categoryTagColor).clipShape(Capsule())
                                }
                                Text(lang.tr(item.subtitleKey)).font(.system(size: 12.0 * uiScale)).fontWeight(appearance.systemFontWeight).foregroundColor(.secondary).multilineTextAlignment(.center)
                            }
                            .padding(.horizontal, 20.0 * uiScale)
                            Spacer(minLength: 12.0 * uiScale)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: filteredWidgets.count > 1 ? .automatic : .never))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                Button(action: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    
                    if let def = activeWidget {
                        if def.manager.isAddedToDesktop {
                            withAnimation(.easeInOut(duration: 0.22)) {
                                def.manager.isAddedToDesktop = false
                                viewModel.compactPages()
                                currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
                            }
                        } else {
                            let target = viewModel.findAvailableSlot(
                                forRows: def.sizeRows,
                                forCols: def.sizeCols,
                                preferPage: currentPage
                            )
                            def.manager.widgetPage = target.page
                            def.manager.widgetRow = target.row
                            def.manager.widgetCol = target.col
                            
                            withAnimation(.easeInOut(duration: 0.22)) {
                                def.manager.isAddedToDesktop = true
                                viewModel.compactPages()
                                currentPage = target.page
                            }
                        }
                    }
                    isPresented = false
                }) {
                    HStack(spacing: 8.0 * uiScale) {
                        if isCurrentAdded {
                            Image(systemName: "checkmark.circle.fill").font(.system(size: 16.0 * uiScale, weight: appearance.systemFontWeight))
                            Text(lang.tr("already_added")).font(.system(size: 16.0 * uiScale, weight: appearance.systemFontWeight))
                        } else {
                            Image(systemName: "plus.circle.fill").font(.system(size: 16.0 * uiScale, weight: appearance.systemFontWeight))
                            Text(lang.tr("add_to_home")).font(.system(size: 16.0 * uiScale, weight: appearance.systemFontWeight))
                        }
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 14.0 * uiScale)
                    .background(appearance.accentTextColor)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 16.0 * uiScale, style: .continuous))
                }
                .padding(.horizontal, 24.0 * uiScale).padding(.bottom, 28.0 * uiScale)
            }
            .fontWeight(appearance.systemFontWeight)
            .navigationTitle(lang.tr("add_widget_nav_title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(lang.tr("close")) { isPresented = false }
                        .font(.system(size: 16.0 * uiScale, weight: appearance.systemFontWeight))
                        .foregroundColor(appearance.accentTextColor)
                }
            }
            .presentationDetents([.fraction(0.85), .large])
        }
    }
}
