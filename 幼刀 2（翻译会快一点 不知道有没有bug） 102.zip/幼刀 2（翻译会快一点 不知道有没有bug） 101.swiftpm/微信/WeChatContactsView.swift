import SwiftUI

// 📄 微信通讯录独立视图
struct WeChatContactsView: View {
    let contacts = ["阿尼亚", "陈晨", "马化腾", "张小龙", "张三", "李四", "王五"]
    
    var body: some View {
        List {
            Section {
                contactRow(icon: "person.badge.plus.fill", color: .orange, title: "新的朋友".tr)
                contactRow(icon: "person.3.fill", color: .green, title: "群聊".tr)
                contactRow(icon: "tag.fill", color: .blue, title: "标签".tr)
                contactRow(icon: "person.crop.square.fill", color: .blue, title: "公众号".tr)
            }
            
            Section(header: Text("A")) { contactCell(name: "阿尼亚") }
            Section(header: Text("C")) { contactCell(name: "陈晨") }
            Section(header: Text("M")) { contactCell(name: "马化腾") }
            Section(header: Text("Z")) {
                contactCell(name: "张小龙")
                contactCell(name: "张三")
            }
            
            Text("\(contacts.count) 位联系人".tr)
                .frame(maxWidth: .infinity, alignment: .center)
                .font(.system(size: 14))
                .foregroundColor(.secondary)
                .listRowBackground(Color.clear)
                .listRowSeparator(.hidden)
        }
        .listStyle(.plain)
    }
    
    private func contactRow(icon: String, color: Color, title: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(.white).frame(width: 40, height: 40)
                .background(color).cornerRadius(4)
            Text(title).font(.system(size: 16))
        }
        .padding(.vertical, 4)
    }
    
    private func contactCell(name: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "person.fill")
                .foregroundColor(.gray.opacity(0.8)).frame(width: 40, height: 40)
                .background(Color(UIColor.secondarySystemFill)).cornerRadius(4)
            Text(name).font(.system(size: 16))
        }
        .padding(.vertical, 4)
    }
}
