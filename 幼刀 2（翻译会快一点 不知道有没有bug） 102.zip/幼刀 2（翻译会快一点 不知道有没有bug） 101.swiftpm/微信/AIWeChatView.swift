// 📄 替换文件：微信/AIWeChatView.swift (瘦身版：纯净入口与路由)
import SwiftUI

// MARK: - 1. 微信独立插件身份证
final class WeChatAppPlugin: BaseAppPlugin {
    override class var id: String { "wechat" }
    override class var name: String { "微信" }
    override class var icon: String { "message.fill" }
    override class var colorName: String { "green" }
    override class func buildView(show: Binding<Bool>) -> AnyView {
        AnyView(AIWeChatView(show: show))
    }
}

// MARK: - 2. 微信总路由容器
struct AIWeChatView: View {
    @Binding var show: Bool
    @AppStorage("WeChat_IsLoggedIn") private var isLoggedIn: Bool = false
    @ObservedObject var appearance = SystemAppearance.shared 
    
    var body: some View {
        Group {
            if isLoggedIn {
                WeChatMainView(show: $show, isLoggedIn: $isLoggedIn)
            } else {
                WeChatAuthRootView(show: $show, isLoggedIn: $isLoggedIn)
            }
        }
        .preferredColorScheme(appearance.colorScheme)
        // 桌面全局右滑退出手势
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
}
